document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('event-filter-form');
  const resultsContainer = document.getElementById('event-results');

  // Load all events when page first loads
  loadEvents();

  // Event listener for filter form submission
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const date = document.getElementById('date').value;
    const location = document.getElementById('location').value;
    const categories = Array.from(document.querySelectorAll('input[name="category"]:checked'))
      .map(cb => cb.value);

    const params = new URLSearchParams();
    if (date) params.append('date', date);
    if (location) params.append('location', location);
    if (categories.length > 0) params.append('categories', categories.join(','));

    loadEvents(params.toString());
  });

  // Reset clears results or reloads all events
  form.addEventListener('reset', () => {
    loadEvents(); // reload all events
  });

  // Main reusable function to load events
  async function loadEvents(query = '') {
    try {
      const res = await fetch(`/api/events${query ? '?' + query : ''}`);
      const events = await res.json();
      renderEvents(events);
    } catch (err) {
      console.error('Error loading events:', err);
      resultsContainer.innerHTML = `<p class="error">Failed to load events. Please try again later.</p>`;
    }
  }

  // Function to render events
  function renderEvents(events) {
    if (!events.length) {
      resultsContainer.innerHTML = `<p class="no-results">No events found.</p>`;
      return;
    }

    resultsContainer.innerHTML = events.map(event => `
      <div class="event-card">
        <h3>${event.event_name}</h3>
        <img src="${event.image_url}" alt="${event.event_name}" class="event-image">
        <p><strong>Date:</strong> ${new Date(event.date).toDateString()}</p>
        <p><strong>Location:</strong> ${event.location}</p>
        <p><strong>Category:</strong> ${event.category_name}</p>
        <p>${event.short_description || ''}</p>
        <a href="eventDetails.html?id=${event.event_id}">View Details</a>
      </div>
    `).join('');
  }
});