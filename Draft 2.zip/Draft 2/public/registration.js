// register.js

document.addEventListener("DOMContentLoaded", async () => {
  const eventSelect = document.getElementById("event_id");
  const messageBox = document.getElementById("message");

  // Fetch events from backend
  try {
    const res = await fetch("/api/events");
    const events = await res.json();

    // Create default option
    eventSelect.innerHTML = `<option value="">-- Select an event --</option>`;

    // Loop through events to populate dropdown
    events.forEach(event => {
      const option = document.createElement("option");
      option.value = event.event_id;
      option.textContent = `${event.event_name} (${event.location})`;
      eventSelect.appendChild(option);
    });

    // Auto-select event if user came from Event Details page
    const params = new URLSearchParams(window.location.search);
    const selectedEventId = params.get("event_id");

    if (selectedEventId) {
      eventSelect.value = selectedEventId; // auto-select event in dropdown
     }
    } catch (err) {
    console.error("Failed to load events:", err);
    eventSelect.innerHTML = `<option value="">Could not load events</option>`;
  }

  // Handle registration form submit
  const form = document.getElementById("registrationForm");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = {
      full_name: form.full_name.value.trim(),
      email: form.email.value.trim(),
      phone: form.phone.value.trim(),
      event_id: parseInt(form.event_id.value),
      ticket_type: form.ticket_type.value,
      ticket_quantity: parseInt(form.ticket_quantity.value),
      payment_status: form.payment_status.value
    };

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (res.ok) {
        messageBox.textContent = data.message;
        messageBox.style.color = "green";
        form.reset();
      } else {
        messageBox.textContent = data.error || "Failed to register.";
        messageBox.style.color = "red";
      }
    } catch (err) {
      console.error("Registration error:", err);
      messageBox.textContent = "Something went wrong.";
      messageBox.style.color = "red";
    }
  });
});




document.addEventListener("DOMContentLoaded", async () => {
  const eventSelect = document.getElementById("eventSelect");
  const tableBody = document.querySelector("#registrationsTable tbody");

  // Fetch all events to populate dropdown
  try {
    const res = await fetch("/api/events");
    const events = await res.json();

    events.forEach(event => {
      const option = document.createElement("option");
      option.value = event.event_id;
      option.textContent = `${event.event_name} (${event.location})`;
      eventSelect.appendChild(option);
    });
  } catch (err) {
    console.error("Failed to load events:", err);
  }


  //////NEW MNEW NEW NEW
  // After populating dropdown
      const params = new URLSearchParams(window.location.search);
      const selectedEventId = params.get("event_id");

      if (selectedEventId) {
        eventSelect.value = selectedEventId;
        eventSelect.dispatchEvent(new Event('change')); // auto-load registrations
      }

//------------------------


  // Load registrations when event is selected
  eventSelect.addEventListener("change", async () => {
    const eventId = eventSelect.value;
    tableBody.innerHTML = ""; // clear previous

    if (!eventId) return;

    try {
      const res = await fetch(`/api/registrations/${eventId}`);
      const registrations = await res.json();

      if (registrations.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="9">No registrations found for this event.</td></tr>`;
        return;
      }

      registrations.forEach((reg, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${index + 1}</td>
          <td>${reg.full_name}</td>
          <td>${reg.email}</td>
          <td>${reg.phone || '-'}</td>
          <td>${reg.ticket_type}</td>
          <td>${reg.ticket_quantity}</td>
          <td>K${reg.total_amount}</td>
          <td>${reg.payment_status}</td>
          <td>${new Date(reg.registered_at).toLocaleString()}</td>
        `;
        tableBody.appendChild(row);
      });
    } catch (err) {
      console.error("Failed to load registrations:", err);
    }
  });
});

