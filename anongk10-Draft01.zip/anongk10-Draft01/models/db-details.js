// Database connection details for MySQL database 
module.exports = {
  host: "127.0.0.1",  
  user: "root",
  password: "",
  database : "charityevents_db",
  port: 3306
};