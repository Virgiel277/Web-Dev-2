document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('events');
  const viewMoreBtn = document.createElement('button');
  viewMoreBtn.textContent = 'View More';
  viewMoreBtn.id = 'viewMoreBtn';
  viewMoreBtn.style.display = 'none';
  container.insertAdjacentElement('afterend', viewMoreBtn);

  fetch('/api/events')
    .then(res => res.json())
    .then(events => {
      if (!events || events.length === 0) {
        container.innerHTML = `<p>No events found. Check back soon!</p>`;
        return;
      }

      events.sort((a, b) => new Date(a.date) - new Date(b.date));
      const limitedEvents = events.slice(0, 3);
      displayEvents(limitedEvents, container);

      if (events.length > 3) viewMoreBtn.style.display = 'block';

      viewMoreBtn.addEventListener('click', () => {
        container.innerHTML = '';
        displayEvents(events, container);
        viewMoreBtn.style.display = 'none';
      });
    })
    .catch(err => {
      console.error('Failed to load events:', err);
      container.innerHTML = `<p>Error loading events. Please try again later.</p>`;
    });
});

function displayEvents(events, container) {
  events.forEach(event => {
    const div = document.createElement('div');
    div.classList.add('event-card');

    div.innerHTML = `
      <h3>${event.event_name}</h3>
      <img src="${event.image_url}" alt="${event.event_name}" class="event-image">
      <p>${event.short_description}</p>
      <p><strong>Date:</strong> ${new Date(event.date).toDateString()}</p>
      <p><strong>Location:</strong> ${event.location}</p>
      <p><strong>Category:</strong> ${event.category_id}</p>
      <a href="eventDetails.html?id=${event.event_id}" class="btn">View Details</a>
    `;
    container.appendChild(div);
  });
}

//-----------------EVENTS CALENDAR----------------
// Sample event data with dates and optional suspension
const events = [
  { title: "Charity Run", date: "2025-12-25" },
  { title: "Food Drive", date: "2025-09-10" },
  { title: "Fundraising Gala", date: "2025-10-05" },
  { title: "Community Clean-Up", date: "2025-08-28", suspended: true, reason: "Severe Weather" } // suspended example
];

function loadEvents() {
  const eventList = document.getElementById("event-list");
  const today = new Date();

  events.forEach(event => {
    const eventDate = new Date(event.date);
    let status = "";

    if (event.suspended) {
      status = `suspended`;
    } else {
      status = eventDate >= today ? "upcoming" : "past";
    }

    const eventItem = document.createElement("div");
    eventItem.classList.add("event-item");

    eventItem.innerHTML = `
      <div class="event-details">
        <div class="event-title">${event.title}</div>
        <div class="event-date">${eventDate.toDateString()}</div>
      </div>
      <div class="event-status ${status}">
        ${status === "suspended" ? `Suspended (${event.reason})` : status.charAt(0).toUpperCase() + status.slice(1)}
      </div>
    `;

    eventList.appendChild(eventItem);
  });
}

// Load events on page load
document.addEventListener("DOMContentLoaded", loadEvents);
