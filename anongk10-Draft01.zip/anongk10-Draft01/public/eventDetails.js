//-----------------EVENT DETAILS PAGE----------------
document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('event-details');

  // Show a loading message
  container.innerHTML = `
    <div class="loader-card">
      <div class="spinner"></div>
      <p>Loading event details...</p>
    </div>
  `;

  // Get the event ID from URL
  const params = new URLSearchParams(window.location.search);
  const eventId = params.get('id');

  if (!eventId) {
    container.innerHTML = `<p>Error: No event selected. Please go back to the home page.</p>`;
    return;
  }

  // Fetch single event details from your backend
  fetch(`/api/events/${eventId}`)
    .then(res => {
      if (!res.ok) throw new Error('Failed to fetch event details');
      return res.json();
    })
    .then(event => {
      if (!event || Object.keys(event).length === 0) {
        container.innerHTML = `<p>Event not found.</p>`;
        return;
      }

      // Display event details
      container.innerHTML = `
        <div class="event-details-card">
          <h2>${event.event_name}</h2>
          <img src="${event.image_url}" alt="${event.event_name}" class="event-details-image">

          <div class="event-info">
            <p><strong>Date:</strong> ${new Date(event.date).toDateString()}</p>
            <p><strong>Location:</strong> ${event.location}</p>
            <p><strong>Category:</strong> ${event.catgory_id}</p>
            <p><strong>Description:</strong> ${event.description}</p>
          </div>

          <div class="ticket-section">
            <h3>Ticket Details</h3>
            <p><strong>Price:</strong> K${event.ticket_price}</p>
            <p><strong>Target Amount:</strong> K${event.target_amount}</p>
          </div>

          <button class="register-btn" id="registerBtn">Register Now</button>
        </div>
      `;

       const card = container.querySelector(".event-details-card");

      // Add "View Registrations" button
      const viewRegsBtn = document.createElement("button");
      viewRegsBtn.textContent = "View Registrations";
      viewRegsBtn.classList.add("view-registrations-btn");
      card.appendChild(viewRegsBtn);

      // Register button click → go to registration page
      const registerBtn = document.getElementById('registerBtn');
      registerBtn.addEventListener('click', () => {
        window.location.href = `registration.html?event_id=${event.event_id}`;
      });

      // View Registrations button click → go to registrations dashboard
      viewRegsBtn.addEventListener("click", () => {
        window.location.href = `registrations.html?event_id=${event.event_id}`;
      });

    })
    .catch(err => {
      console.error(err);
      container.innerHTML = `<p>Error loading event details. Please try again later.</p>`;
    });
});
