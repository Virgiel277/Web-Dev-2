// controllerAPI/api-controller.js

// Import necessary modules
var express = require("express");
var router = express.Router();
var dbcon = require("../models/database");

// Create a connection to the database
var connection = dbcon.getconnection();
connection.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err);
  } else {
    console.log("Connected to the database");
  }
});

// ------------------------ ROUTES ------------------------ //

// Get all charity events
router.get("/events", function (req, res) {
  const sql = "SELECT * FROM events";
  connection.query(sql, function (err, results) {
    if (err) {
      console.error("SQL Error:", err);
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Get Event Details by ID
router.get("/events/:id", (req, res) => {
  const eventId = req.params.id;
  const sql = "SELECT * FROM events WHERE event_id = ?";
  connection.query(sql, [eventId], (err, results) => {
    if (err) {
      console.error("SQL Error:", err);
      return res.status(500).json({ error: err.message });
    }
    if (results.length === 0)
      return res.status(404).json({ error: "Event not found." });
    res.json(results[0]);
  });
});

// Get all Categories
router.get("/categories", (req, res) => {
  const sql = "SELECT category_id, name FROM categories";
  connection.query(sql, (err, rows) => {
    if (err) {
      console.error("SQL Error:", err);
      return res.status(500).json({ error: err.message });
    }
    res.json(rows);
  });
});

// Search events by date, location, or category
router.get("/search", (req, res) => {
  const { date, location, category_id } = req.query;

  let query = `
    SELECT 
      e.event_id, 
      e.name AS event_name, 
      e.description, 
      e.location, 
      e.event_date, 
      e.ticket_price,
      e.ticket_type,
      e.image_url,
      c.name AS category_name
    FROM events e
    JOIN categories c ON e.category_id = c.category_id
    WHERE e.suspended = 0
  `;

  const values = [];

  if (date) {
    query += " AND DATE(e.event_date) = ?";
    values.push(date);
  }
  if (location) {
    query += " AND e.location LIKE ?";
    values.push(`%${location}%`);
  }
  if (category_id) {
    query += " AND e.category_id = ?";
    values.push(category_id);
  }

  query += " ORDER BY e.event_date ASC";

  connection.query(query, values, (err, rows) => {
    if (err) {
      console.error("Search Error:", err);
      return res.status(500).json({ error: "Failed to search events" });
    }
    if (rows.length === 0) {
      return res
        .status(404)
        .json({ message: "No events match your search criteria." });
    }
    res.json(rows);
  });
});

// -------------------- REGISTER FOR EVENT --------------------
router.post('/register', (req, res) => {
  const { full_name, email, phone, event_id, ticket_type, ticket_quantity, payment_status } = req.body;

  // Basic validation
  if (!full_name || !email || !event_id) {
    return res.status(400).json({ error: "Full name, email, and event ID are required." });
  }

  // Calculate total amount (optional)
  const getTicketPriceQuery = 'SELECT ticket_price FROM events WHERE event_id = ?';
  connection.query(getTicketPriceQuery, [event_id], (err, result) => {
    if (err) {
      console.error("Error fetching ticket price:", err);
      return res.status(500).json({ error: "Server error fetching ticket price." });
    }

    if (result.length === 0) {
      return res.status(404).json({ error: "Event not found." });
    }

    const ticket_price = result[0].ticket_price;
    const total_amount = ticket_price * ticket_quantity;

    // Insert registration data
    const insertQuery = `
      INSERT INTO registrations 
      (full_name, email, phone, event_id, ticket_type, ticket_quantity, payment_status, total_amount, registered_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `;

    const values = [
      full_name, email, phone, event_id,
      ticket_type, ticket_quantity, payment_status, total_amount
    ];

    connection.query(insertQuery, values, (err, results) => {
      if (err) {
        console.error("Error saving registration:", err);
        return res.status(500).json({ error: "Failed to save registration." });
      }

      return res.status(200).json({ message: "Registration successful!" });
    });
  });
});

// -------------------- GET REGISTRATIONS BY EVENT --------------------
router.get('/registrations/:event_id', (req, res) => {
  const eventId = req.params.event_id;

  const query = `
    SELECT r.registration_id, r.full_name, r.email, r.phone, r.ticket_type, r.ticket_quantity, r.payment_status, r.total_amount, r.registered_at,
           e.event_name, e.date, e.location
    FROM registrations r
    JOIN events e ON r.event_id = e.event_id
    WHERE r.event_id = ?
    ORDER BY r.registered_at DESC
  `;

  connection.query(query, [eventId], (err, results) => {
    if (err) {
      console.error("Error fetching registrations:", err);
      return res.status(500).json({ error: "Failed to fetch registrations." });
    }

    res.json(results);
  });
});


// Export the router so server.js can use it
module.exports = router;
