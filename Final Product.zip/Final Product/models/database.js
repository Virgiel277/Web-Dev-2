const dbDetails = require("./db-details");
const mysql = require('mysql2');

// Create a single pool instance and export convenience methods.
// This avoids creating multiple pools on repeated require() calls.
const pool = mysql.createPool({
	host: dbDetails.host,
	user: dbDetails.user,
	password: dbDetails.password,
	database: dbDetails.database,
	port: dbDetails.port || 3306,
	waitForConnections: true,
	connectionLimit: 10,
	queueLimit: 0
});

// Export pool and a promise-based query helper for async/await usage
module.exports = {
	pool: pool,
	query: function (sql, params) {
		return new Promise((resolve, reject) => {
			pool.query(sql, params, (err, results) => {
				if (err) return reject(err);
				resolve(results);
			});
		});
	}
};
