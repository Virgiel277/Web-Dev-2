// Database connection details for MySQL database 
module.exports = {
  // Use XAMPP local MySQL (localhost) so the dashboard can connect to your DB
  host: "localhost",
  user: "root",
  password: "",
  database: "charityevents_db",
  port: 3306
};