const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname))); // serve your HTML files

// ✅ MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "", // change if you have a password
  database: "charity_events" // make sure your DB name matches this
});

db.connect((err) => {
  if (err) {
    console.error("❌ Database connection failed:", err);
  } else {
    console.log("✅ Connected to MySQL database!");
  }
});

// ✅ API ROUTES

// Get all events
app.get("/api/events", (req, res) => {
  const query = `
    SELECT e.*, o.name AS organisation, c.name AS category 
    FROM events e
    LEFT JOIN organisations o ON e.org_id = o.org_id
    LEFT JOIN categories c ON e.category_id = c.category_id
    ORDER BY e.event_date ASC
  `;
  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching events:", err);
      res.status(500).json({ error: "Failed to fetch events" });
    } else {
      res.json(results);
    }
  });
});

// Get single event details by ID
app.get("/api/events/:id", (req, res) => {
  const eventId = req.params.id;
  const query = `
    SELECT e.*, o.name AS organisation, c.name AS category 
    FROM events e
    LEFT JOIN organisations o ON e.org_id = o.org_id
    LEFT JOIN categories c ON e.category_id = c.category_id
    WHERE e.event_id = ?
  `;
  db.query(query, [eventId], (err, results) => {
    if (err) {
      console.error("Error fetching event:", err);
      res.status(500).json({ error: "Failed to fetch event details" });
    } else if (results.length === 0) {
      res.status(404).json({ error: "Event not found" });
    } else {
      res.json(results[0]);
    }
  });
});

// Register for an event
app.post("/api/registrations", (req, res) => {
  const { event_id, full_name, email, phone, tickets } = req.body;

  if (!event_id || !full_name || !email || !tickets) {
    return res.status(400).json({ error: "Please fill all required fields" });
  }

  const query = `
    INSERT INTO registrations (event_id, full_name, email, phone, tickets)
    VALUES (?, ?, ?, ?, ?)
  `;

  db.query(query, [event_id, full_name, email, phone, tickets], (err, result) => {
    if (err) {
      console.error("Error saving registration:", err);
      res.status(500).json({ error: "Server error saving registration" });
    } else {
      res.json({ message: "Registration successful!" });
    }
  });
});

// Fallback route for missing pages
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
