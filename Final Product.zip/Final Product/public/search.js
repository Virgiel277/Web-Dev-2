async function searchEvents() {
  const query = document.getElementById("searchInput").value.trim();
  const resultsContainer = document.getElementById("results");

  if (!query) {
    resultsContainer.innerHTML = "<p>Please enter a search term.</p>";
    return;
  }

  try {
    const res = await fetch(`http://localhost:3000/api/search?q=${encodeURIComponent(query)}`);
    const results = await res.json();

    if (results.length === 0) {
      resultsContainer.innerHTML = "<p>No events found.</p>";
      return;
    }

    resultsContainer.innerHTML = results
      .map(
        (e) => `
        <div class="event-card">
          <h3>${e.name}</h3>
          <p>${e.description || "No description"}</p>
          <p><strong>Location:</strong> ${e.location}</p>
          <p><strong>Date:</strong> ${new Date(e.event_date).toLocaleString()}</p>
          <a href="event-details.html?id=${e.event_id}" class="button">View Details</a>
        </div>
      `
      )
      .join("");
  } catch (err) {
    console.error(err);
    resultsContainer.innerHTML = "<p>Failed to load results.</p>";
  }
}
