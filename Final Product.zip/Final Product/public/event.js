// Helper: get query string ?id=xxx
function getEventId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

// Load event details
async function loadEventDetails() {
  const eventId = getEventId();
  const container = document.getElementById("event-details");

  if (!eventId) {
    container.innerHTML = "<p>No event selected.</p>";
    return;
  }

  try {
    const res = await fetch(`http://localhost:3000/api/events/${eventId}`);
    if (!res.ok) throw new Error("Event not found");

    const event = await res.json();

    container.innerHTML = `
      <h3>${event.name}</h3>
      <p><strong>Organisation ID:</strong> ${event.org_id ?? "N/A"}</p>
      <p><strong>Category ID:</strong> ${event.category_id ?? "N/A"}</p>
      <p><strong>Description:</strong> ${event.description}</p>
      <p><strong>Location:</strong> ${event.location}</p>
      <p><strong>Date:</strong> ${new Date(event.event_date).toLocaleString()}</p>
      <p><strong>Tickets:</strong> ${event.ticket_type === "free" ? "Free" : "$" + event.ticket_price}</p>
      <p><strong>Goal Amount:</strong> $${(event.goal_amount ?? 0).toLocaleString()}</p>
      <p><strong>Progress:</strong> $${(event.progress_amount ?? 0).toLocaleString()}</p>
      <button id="register-btn" class="register-btn">Register</button>
    `;

    // Redirect to registration page when clicked
    document.getElementById("register-btn").addEventListener("click", () => {
      // Redirect to registration page with event_id in URL
      window.location.href = `registration.html?event_id=${eventId}`;
    });

  } catch (err) {
    console.error(err);
    container.innerHTML = "<p>Failed to load event details.</p>";
  }
}

document.addEventListener("DOMContentLoaded", loadEventDetails);
