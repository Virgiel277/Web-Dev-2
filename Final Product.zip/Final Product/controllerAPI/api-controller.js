const express = require('express');
const router = express.Router();

// Mount sub-routers
router.use('/events', require('./events-controller'));
router.use('/categories', require('./categories-controller'));
router.use('/search', require('./search-controller'));
router.use('/registrations', require('./registrations-controller'));

module.exports = router;
