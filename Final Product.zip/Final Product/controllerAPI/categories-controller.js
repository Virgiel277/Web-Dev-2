const express = require('express');
const router = express.Router();
const db = require('../models/database');

// Get all Categories
router.get('/', async (req, res) => {
  const sql = 'SELECT category_id, name FROM categories';
  try {
    const rows = await db.query(sql);
    res.json(rows);
  } catch (err) {
    console.error('SQL Error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
