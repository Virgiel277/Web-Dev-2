const express = require('express');
const router = express.Router();
const db = require('../models/database');

// Search events by date, location, or category
router.get('/', async (req, res) => {
  const { date, location, category_id } = req.query;

  let query = `
    SELECT 
      e.event_id, 
      e.name AS event_name, 
      e.description, 
      e.location, 
      e.event_date, 
      e.ticket_price,
      e.ticket_type,
      e.image_url,
      c.name AS category_name
    FROM events e
    JOIN categories c ON e.category_id = c.category_id
    WHERE e.suspended = 0
  `;

  const values = [];

  if (date) {
    query += ' AND DATE(e.event_date) = ?';
    values.push(date);
  }
  if (location) {
    query += ' AND e.location LIKE ?';
    values.push(`%${location}%`);
  }
  if (category_id) {
    query += ' AND e.category_id = ?';
    values.push(category_id);
  }

  query += ' ORDER BY e.event_date ASC';

  try {
    const rows = await db.query(query, values);
    if (!rows || rows.length === 0) {
      return res.status(404).json({ message: 'No events match your search criteria.' });
    }
    res.json(rows);
  } catch (err) {
    console.error('Search Error:', err);
    res.status(500).json({ error: 'Failed to search events' });
  }
});

module.exports = router;
