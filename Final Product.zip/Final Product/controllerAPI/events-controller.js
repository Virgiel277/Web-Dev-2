const express = require('express');
const router = express.Router();
const db = require('../models/database');

// Get all charity events
router.get('/', async function (req, res) {
  const sql = 'SELECT * FROM events WHERE suspended = 0';
  try {
    const results = await db.query(sql);
    res.json(results);
  } catch (err) {
    console.error('SQL Error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get Event Details by ID
router.get('/:id', async (req, res) => {
  const eventId = req.params.id;
  const sql = 'SELECT * FROM events WHERE event_id = ? AND suspended = 0';
  try {
    const results = await db.query(sql, [eventId]);
    if (!results || results.length === 0) return res.status(404).json({ error: 'Event not found.' });
    res.json(results[0]);
  } catch (err) {
    console.error('SQL Error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
