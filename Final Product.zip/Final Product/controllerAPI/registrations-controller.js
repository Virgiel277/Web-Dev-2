const express = require('express');
const router = express.Router();
const db = require('../models/database');

// Register for an event
router.post('/', async (req, res) => {
  const { full_name, email, phone, event_id, ticket_type, ticket_quantity, payment_status } = req.body;

  if (!full_name || !email || !event_id) {
    return res.status(400).json({ error: 'Full name, email, and event ID are required.' });
  }

  try {
    const result = await db.query('SELECT ticket_price FROM events WHERE event_id = ?', [event_id]);
    if (!result || result.length === 0) {
      return res.status(404).json({ error: 'Event not found.' });
    }

    const ticket_price = result[0].ticket_price || 0;
    const qty = Number(ticket_quantity) || 1;
    const total_amount = ticket_price * qty;

    const insertQuery = `
      INSERT INTO registrations 
      (full_name, email, phone, event_id, ticket_type, ticket_quantity, payment_status, total_amount, registered_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `;

    const values = [
      full_name, email, phone, event_id,
      ticket_type, qty, payment_status, total_amount
    ];

    await db.query(insertQuery, values);
    return res.status(200).json({ message: 'Registration successful!' });
  } catch (err) {
    console.error('Error saving registration:', err);
    return res.status(500).json({ error: 'Failed to save registration.' });
  }
});

// Get registrations for a specific event
router.get('/:event_id', async (req, res) => {
  const eventId = req.params.event_id;

  const query = `
    SELECT r.registration_id, r.full_name, r.email, r.phone, r.ticket_type, r.ticket_quantity, r.payment_status, r.total_amount, r.registered_at,
           e.name AS event_name, e.event_date AS date, e.location
    FROM registrations r
    JOIN events e ON r.event_id = e.event_id
    WHERE r.event_id = ?
    ORDER BY r.registered_at DESC
  `;

  try {
    const results = await db.query(query, [eventId]);
    res.json(results);
  } catch (err) {
    console.error('Error fetching registrations:', err);
    res.status(500).json({ error: 'Failed to fetch registrations.' });
  }
});

module.exports = router;
