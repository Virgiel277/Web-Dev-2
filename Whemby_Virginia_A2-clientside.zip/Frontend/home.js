async function loadEvents() {
  try {
    const res = await fetch('http://localhost:3000/api/events');
    const events = await res.json();

    const container = document.getElementById('events-list');
    container.innerHTML = "";

    if (events.length === 0) {
      container.innerHTML = "<p>No events available.</p>";
      return;
    }

    events.forEach(event => {
      const card = document.createElement('div');
      card.classList.add('event-card');

      card.innerHTML = `
        <h3>${event.name}</h3>
        <p><strong>Location:</strong> ${event.location}</p>
        <p><strong>Date:</strong> ${new Date(event.event_date).toLocaleString()}</p>
        <p><strong>Category:</strong> ${event.category}</p>
        <p><strong>Tickets:</strong> ${event.ticket_type === 'free' ? 'Free' : '$' + event.ticket_price}</p>
        <button onclick="viewDetails(${event.event_id})">View Details</button>
      `;

      container.appendChild(card);
    });
  } catch (err) {
    console.error("Unable to load events:", err);
  }
}

function viewDetails(id) {
  // redirect to event details page
  window.location.href = `event.html?id=${id}`;
}

document.addEventListener('DOMContentLoaded', loadEvents);
