function getEventId() {
  return new URLSearchParams(window.location.search).get("id");
}

document.getElementById("register-form").addEventListener("submit", e => {
  e.preventDefault();
  const form = new FormData(e.target);
  const name = form.get("name");
  const tickets = form.get("tickets");
  const eventId = getEventId();
  document.getElementById("confirmation").innerHTML = `
    <p>✅ Thank you, ${name}! You registered for Event #${eventId} with ${tickets} ticket(s).</p>
    <p><em>This feature is under construction.</em></p>
  `;
});
