function getEventId() {
  return new URLSearchParams(window.location.search).get("id");
}

async function loadEventDetails() {
  const id = getEventId();
  const res = await fetch(`http://localhost:3000/api/events/${id}`);
  const e = await res.json();
  const container = document.getElementById("event-details");
  container.innerHTML = `
    <h3>${e.name}</h3>
    <p><strong>Description:</strong> ${e.description}</p>
    <p><strong>Location:</strong> ${e.location}</p>
    <p><strong>Date:</strong> ${new Date(e.event_date).toLocaleString()}</p>
    <p><strong>Tickets:</strong> ${e.ticket_type === 'free' ? 'Free' : '$' + e.ticket_price}</p>
    <button onclick="window.location.href='register.html?id=${e.event_id}'">Register</button>
  `;
}
document.addEventListener("DOMContentLoaded", loadEventDetails);
