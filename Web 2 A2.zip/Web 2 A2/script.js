const API_BASE = "http://localhost:3000/api"; // backend server

// ============= HOME PAGE =============
async function loadHomePage() {
  const container = document.getElementById("events-container");
  if (!container) return; // only run on Home page

  try {
    const res = await fetch(`${API_BASE}/events`);
    const events = await res.json();

    if (!events.length) {
      container.innerHTML = "<p>No upcoming events.</p>";
      return;
    }

    container.innerHTML = events.map(ev => `
      <div class="work-item wide">
        <div style="padding: 20px;">
          <h3>${ev.name}</h3>
          <p><strong>Date:</strong> ${new Date(ev.date).toLocaleDateString()}</p>
          <p><strong>Location:</strong> ${ev.location}</p>
          <a href="event.html?id=${ev.id}">View Details</a>
        </div>
      </div>
    `).join("");
  } catch (err) {
    console.error("Error loading events:", err);
    container.innerHTML = "<p>Error loading events.</p>";
  }
}

// ============= EVENT DETAILS PAGE =============
async function loadEventDetails() {
  const detailsDiv = document.getElementById("event-details");
  if (!detailsDiv) return;

  const params = new URLSearchParams(window.location.search);
  const eventId = params.get("id");
  if (!eventId) {
    detailsDiv.innerHTML = "<p>Invalid event.</p>";
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/events/${eventId}`);
    if (!res.ok) throw new Error("Event not found");
    const ev = await res.json();

    detailsDiv.innerHTML = `
      <h3>${ev.name}</h3>
      <p><strong>Date:</strong> ${new Date(ev.date).toLocaleString()}</p>
      <p><strong>Location:</strong> ${ev.location}</p>
      <p><strong>Description:</strong> ${ev.description}</p>
      <p><strong>Tickets:</strong> ${ev.ticket_type} - $${ev.ticket_price}</p>
    `;

    const regBtn = document.getElementById("register-btn");
    if (regBtn) {
      regBtn.onclick = () => {
        window.location.href = `register.html?eventId=${ev.id}`;
      };
    }
  } catch (err) {
    console.error("Error loading event:", err);
    detailsDiv.innerHTML = "<p>Event not found.</p>";
  }
}

// ============= SEARCH PAGE =============
async function setupSearch() {
  const form = document.getElementById("search-form");
  const resultsDiv = document.getElementById("search-results");
  const clearBtn = document.getElementById("clear-btn");
  if (!form) return;

  form.addEventListener("submit", async e => {
    e.preventDefault();
    const query = document.getElementById("search-input").value.toLowerCase();

    try {
      const res = await fetch(`${API_BASE}/events`);
      const events = await res.json();

      const filtered = events.filter(ev =>
        ev.name.toLowerCase().includes(query) ||
        ev.location.toLowerCase().includes(query) ||
        ev.date.toLowerCase().includes(query) ||
        (ev.category && ev.category.toLowerCase().includes(query))
      );

      resultsDiv.innerHTML = filtered.length
        ? filtered.map(ev => `
            <div class="work-item">
              <div style="padding: 20px;">
                <h3>${ev.name}</h3>
                <p>${new Date(ev.date).toLocaleDateString()} - ${ev.location}</p>
                <a href="event.html?id=${ev.id}">View Details</a>
              </div>
            </div>
          `).join("")
        : "<p>No events found.</p>";
    } catch (err) {
      console.error("Search failed:", err);
      resultsDiv.innerHTML = "<p>Error searching events.</p>";
    }
  });

  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      document.getElementById("search-input").value = "";
      resultsDiv.innerHTML = "";
    });
  }
}

// ============= REGISTER PAGE =============
async function setupRegister() {
  const form = document.getElementById("register-form");
  const eventSelect = document.getElementById("event-select");
  const msg = document.getElementById("register-message");
  if (!form) return;

  try {
    const res = await fetch(`${API_BASE}/events`);
    const events = await res.json();

    // Pre-select if coming from event page
    const params = new URLSearchParams(window.location.search);
    const eventId = params.get("eventId");

    eventSelect.innerHTML = `<option value="">Select an event</option>` +
      events.map(ev => `
        <option value="${ev.id}" ${eventId == ev.id ? "selected" : ""}>
          ${ev.name} (${new Date(ev.date).toLocaleDateString()})
        </option>
      `).join("");

    form.addEventListener("submit", async e => {
      e.preventDefault();
      const body = {
        event_id: eventSelect.value,
        name: document.getElementById("name").value,
        email: document.getElementById("email").value
      };

      try {
        const response = await fetch(`${API_BASE}/bookings`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        const result = await response.json();
        msg.textContent = "✅ " + (result.message || "Registration successful");
        form.reset();
      } catch (err) {
        console.error("Registration failed:", err);
        msg.textContent = "❌ Registration failed.";
      }
    });
  } catch (err) {
    console.error("Could not load events:", err);
    msg.textContent = "❌ Could not load events.";
  }
}

// ============= INIT =============
window.onload = () => {
  loadHomePage();
  loadEventDetails();
  setupSearch();
  setupRegister();
};
