const db = require('./event_db');

async function testDB() {
  try {
    const [rows] = await db.query('SELECT * FROM events LIMIT 5');
    console.log("Sample events:", rows);
  } catch (err) {
    console.error(err);
  }
}

testDB();
