// server.js

// Import required modules
var express = require("express");
var path = require("path");
var bodyParser = require("body-parser");
var eventAPI = require("./controllerAPI/api-controller"); // Import API routes

// Initialize Express app
var app = express();

// Parse incoming request bodies
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the "public" folder
app.use(express.static(path.join(__dirname, "public")));

// Mount the API routes
app.use("/api", eventAPI);

// Start the server
var PORT = 3060;
app.listen(PORT, () => {
  console.log(`Server up and running on port ${PORT}`);
});