-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2025 at 10:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `charityevents_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `description`) VALUES
(1, 'Auction', 'Bidding events to raise funds.'),
(2, 'Gala', 'Formal dinners and entertainment to support the underpreviledge.'),
(3, 'Raffle', 'Selling tickets to raise funds for charitable causes.'),
(4, 'Concert', 'Live performances to support charitable causes');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `event_date` datetime NOT NULL,
  `ticket_price` decimal(10,2) DEFAULT 0.00,
  `ticket_type` enum('free','paid') NOT NULL DEFAULT 'free',
  `goal_amount` decimal(10,2) DEFAULT 0.00,
  `progress_amount` decimal(10,2) DEFAULT 0.00,
  `suspended` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `org_id`, `category_id`, `name`, `description`, `location`, `event_date`, `ticket_price`, `ticket_type`, `goal_amount`, `progress_amount`, `suspended`) VALUES
(1, 1, 1, 'Auction', 'Raise funds for homeless.', 'Nature Park', '2025-11-15 13:00:00', 120.00, 'paid', 10000.00, 8600.00, 0),
(2, 1, 2, 'Gala', 'Support children\'s education.', 'Dynasty Restaurant', '2024-09-10 19:00:00', 25.00, 'paid', 8000.00, 8200.00, 0),
(3, 1, 3, ' Art Auction', 'Support youth art programs.', 'National Museum', '2025-03-01 18:00:00', 10.00, 'paid', 5000.00, 3200.00, 1),
(4, 1, 4, 'New Years Concert', 'Help victims of natural disasters.', 'Sir John Guise Stadium', '2025-12-05 10:00:00', 50.00, 'paid', 10000.00, 7500.00, 0),
(5, 1, 2, 'Annual Gala Dinner', 'Raise funds for medical research.', 'Grand Papua Hotel', '2025-09-20 19:00:00', 150.00, 'paid', 15000.00, 10000.00, 0),
(6, 1, 3, 'Raffle Tickets', 'Raise funds for the disabled.', 'Adventure Park', '2025-10-01 09:00:00', 20.00, 'paid', 6000.00, 7000.00, 0),
(7, 1, 4, 'Charity Concert', 'Fund given to cancer patients.', 'Sir John Guise Stadium', '2025-07-15 19:00:00', 100.00, 'paid', 20000.00, 19000.00, 0),
(8, 1, 3, 'School Raffle Tickets', 'Raise awareness for climate action.', 'IBS University', '2025-01-20 09:00:00', 30.00, 'paid', 5000.00, 3000.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `organisations`
--

CREATE TABLE `organisations` (
  `org_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organisations`
--

INSERT INTO `organisations` (`org_id`, `name`, `description`, `contact_email`, `phone`, `website`) VALUES
(1, 'Foundation of Hope', 'Charity organization supporting health, education, and disaster relief.', 'info@foh.org', '+675 123 456', 'http://foundationofhope.org');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `org_id` (`org_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `organisations`
--
ALTER TABLE `organisations`
  ADD PRIMARY KEY (`org_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `organisations`
--
ALTER TABLE `organisations`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `organisations` (`org_id`),
  ADD CONSTRAINT `events_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
