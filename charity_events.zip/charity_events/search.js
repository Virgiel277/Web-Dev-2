// Load categories into dropdown
async function loadCategories() {
  try {
    const res = await fetch("http://localhost:3000/api/categories");
    const categories = await res.json();

    const categorySelect = document.getElementById("category");
    categories.forEach(cat => {
      const option = document.createElement("option");
      option.value = cat.category_id;
      option.textContent = cat.name;
      categorySelect.appendChild(option);
    });
  } catch (err) {
    console.error("Unable to load categories:", err);
  }
}

// Handle search form submission
document.getElementById("search-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const date = document.getElementById("date").value;
  const location = document.getElementById("location").value.trim();
  const category_id = document.getElementById("category").value;

  let url = "http://localhost:3000/api/events/search?";
  const params = [];

  if (date) params.push(`date=${date}`);
  if (location) params.push(`location=${encodeURIComponent(location)}`);
  if (category_id) params.push(`category_id=${category_id}`);

  url += params.join("&");

  try {
    const res = await fetch(url);
    const events = await res.json();

    displayResults(events);
  } catch (err) {
    console.error("Search failed:", err);
    document.getElementById("results").innerHTML = "<p> Search error. Try again.</p>";
  }
});

// Display results
function displayResults(events) {
  const container = document.getElementById("results");
  container.innerHTML = "";

  if (events.length === 0) {
    container.innerHTML = "<p>No events found.</p>";
    return;
  }

  events.forEach(event => {
    const card = document.createElement("div");
    card.classList.add("event-card");

    card.innerHTML = `
      <h3>${event.name}</h3>
      <p><strong>Location:</strong> ${event.location}</p>
      <p><strong>Date:</strong> ${new Date(event.event_date).toLocaleString()}</p>
      <p><strong>Category:</strong> ${event.category}</p>
      <p><strong>Tickets:</strong> ${event.ticket_type === 'free' ? 'Free' : '$' + event.ticket_price}</p>
      <button onclick="viewDetails(${event.event_id})">View Details</button>
    `;

    container.appendChild(card);
  });
}

// Clear filters
function clearFilters() {
  document.getElementById("date").value = "";
  document.getElementById("location").value = "";
  document.getElementById("category").value = "";
  document.getElementById("results").innerHTML = "";
}

// Redirect to event details page
function viewDetails(id) {
  window.location.href = `event.html?id=${id}`;
}

// Load categories on page load
document.addEventListener("DOMContentLoaded", loadCategories);
