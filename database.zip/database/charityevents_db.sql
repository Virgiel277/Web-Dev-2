CREATE DATABASE IF NOT EXISTS charityevents_db;
USE charityevents_db;

CREATE TABLE IF NOT EXISTS categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    org_id INT,
    category_id INT,
    event_name VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    time TIME,
    location VARCHAR(255) NOT NULL,
    image_url VARCHAR(255),
    description TEXT,
    description TEXT,
    ticket_price DECIMAL(10,2),
    ticket_target INT,
    targets_available INT,
    status ENUM('Active', 'Suspended', 'Cancelled') DEFAULT 'Active',
    suspend BOOLEAN DEFAULT FALSE,
    suspended_reason TEXT,
    suspended_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (org_id) REFERENCES organisations(org_id)
);

CREATE TABLE IF NOT EXISTS organisations (
    org_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    mission TEXT,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS registration (
    reg_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
	ticket_type ENUM('Free', 'Student', 'General', 'VIP') DEFAULT 'General',
    ticket_quantity INT DEFAULT 1,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'User') DEFAULT 'Admin'
);

INSERT INTO categories (category_name, description) VALUES 
('Health Awareness', 'Events focused on promoting public health and wellness.', 'October'),
('Fundraiser', 'Events raising money for a specific cause or charity.', 'November'),
('Auction', 'Events where items are sold to the highest bidder.', 'December');

INSERT INTO events 
(event_name, date, location, image_url, short_description, description, category_name, ticket_price, target_amount, suspend, suspended_reason, suspended_at, org_id, total_tickets, tickets_sold, event_time) 
VALUES
('Blood Donation Drive', '2025-10-15', 'Gordons', 'images/blood_drive.jpg', 'Donate blood to save lives.', 'A full day of blood donation with medical staff.', 'Health Awareness', 0, 0, FALSE, NULL, NULL, 1, 0, 0, '09:00:00'),
('Community Health Check', '2025-10-20', 'Boroko', 'images/health_check.jpg', 'Free checkups for all ages.', 'Health experts providing screenings and advice.', 'Health Awareness', 0, 0, FALSE, NULL, NULL, 1, 0, 0, '10:00:00'),
('Charity Gala', '2025-11-05', 'Town', 'images/charity_gala.jpg', 'An evening of fundraising and dinner.', 'Join us for our annual charity gala event.', 'Fundraiser', 150, 5000, FALSE, NULL, NULL, 2, 0, 0, '18:00:00'),
('Art Auction', '2025-11-20', 'Gerehu', 'images/art_auction.jpg', 'Bid on amazing artworks.', 'All proceeds go to local schools.', 'Auction', 50, 2000, FALSE, NULL, NULL, 3, 0, 0, '15:00:00'),
('Health Workshop', '2025-12-01', 'Town', 'images/health_workshop.jpg', 'Learn about healthy lifestyles.', 'Interactive sessions with health experts.', 'Health Awareness', 20, 0, FALSE, NULL, NULL, 1, 0, 0, '11:00:00'),
('Charity Run', '2025-12-10', 'Gordons', 'images/charity_run.jpg', '5k run for a cause.', 'Run to support our local community projects.', 'Fundraiser', 30, 3000, FALSE, NULL, NULL, 2, 0, 0, '07:00:00'),
('Silent Auction', '2025-12-15', 'Boroko', 'images/silent_auction.jpg', 'Bid silently for prizes.', 'Proceeds will help fund community programs.', 'Auction', 25, 1500, TRUE, 'Weather issues', '2025-12-12 10:00:00', 3, 0, 0, '12:00:00'),
('Wellness Fair', '2025-12-20', 'Gerehu', 'images/wellness_fair.jpg', 'A day for health checkups.', 'Free health checkups and consultations.', 'Health Awareness', 0, 0, FALSE, NULL, NULL, 1, 0, 0, '09:00:00'),
('Fundraising Concert', '2025-12-25', 'Town', 'images/fundraising_concert.jpg', 'Concert to raise funds.', 'Enjoy music and support local causes.', 'Fundraiser', 200, 7000, FALSE, NULL, NULL, 2, 0, 0, '19:00:00'),
('Holiday Charity Bazaar', '2025-12-28', 'Boroko', 'images/charity_bazaar.jpg', 'Shop and support local projects.', 'Local vendors selling items to support charity.', 'Fundraiser', 10, 1000, FALSE, NULL, NULL, 2, 0, 0, '10:00:00'),
('Community Auction', '2025-12-30', 'Gordons', 'images/community_auction.jpg', 'Bid for a cause.', 'All proceeds will go to community development.', 'Auction', 15, 1500, FALSE, NULL, NULL, 3, 0, 0, '14:00:00');

INSERT INTO organisations (name, mission, contact_email, contact_phone) VALUES
('Health First', 'Promote health awareness', 'contact@healthfirst.com', '12345678'),
('Charity Works', 'Fundraising for local causes', 'info@charityworks.com', '23456789'),
('Auction House', 'Organize charity auctions', 'support@auctionhouse.com', '34567890');

INSERT INTO users (full_name, email, password, role) VALUES
('Admin User', 'admin@example.com', 'admin123', 'Admin'),
('Tom User', 'user@example.com', 'password1', 'User');