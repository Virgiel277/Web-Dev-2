const express = require('express');
const cors = require('cors');
const db = require('./event_db');  // our DB connection

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

/**
 * 1. Homepage events
 * Get all active/upcoming events (not suspended, date >= NOW)
 */
app.get('/api/events', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT e.event_id, e.name, e.description, e.location, e.event_date, 
             e.ticket_price, e.ticket_type, c.name AS category
      FROM events e
      JOIN categories c ON e.category_id = c.category_id
      WHERE e.suspended = 0
      ORDER BY e.event_date ASC
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Database query failed" });
  }
});

/**
 * 2. Search events
 * Query by optional filters: date, location, category_id
 * Example: /api/events/search?date=2025-11-15&location=Park&category_id=1
 */
app.get('/api/events/search', async (req, res) => {
  try {
    let { date, location, category_id } = req.query;
    let query = `
      SELECT e.event_id, e.name, e.description, e.location, e.event_date, 
             e.ticket_price, e.ticket_type, c.name AS category
      FROM events e
      JOIN categories c ON e.category_id = c.category_id
      WHERE e.suspended = 0
    `;
    let values = [];

    if (date) {
      query += " AND DATE(e.event_date) = ?";
      values.push(date);
    }
    if (location) {
      query += " AND e.location LIKE ?";
      values.push(`%${location}%`);
    }
    if (category_id) {
      query += " AND e.category_id = ?";
      values.push(category_id);
    }

    query += " ORDER BY e.event_date ASC";

    const [rows] = await db.query(query, values);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Search failed" });
  }
});

/**
 * 3. Event details
 * Get one event by ID
 * Example: /api/events/1
 */
app.get('/api/events/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query(`
      SELECT e.event_id, e.name, e.description, e.location, e.event_date, 
             e.ticket_price, e.ticket_type, e.goal_amount, e.progress_amount,
             c.name AS category, o.name AS organisation
      FROM events e
      JOIN categories c ON e.category_id = c.category_id
      JOIN organisations o ON e.org_id = o.org_id
      WHERE e.event_id = ? AND e.suspended = 0
    `, [id]);

    if (rows.length === 0) {
      return res.status(404).json({ error: "Event not found" });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch event details" });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
