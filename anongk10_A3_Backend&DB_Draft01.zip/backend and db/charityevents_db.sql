CREATE TABLE IF NOT EXISTS registrations (
  registration_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  event_id INT NOT NULL,
  ticket_type VARCHAR(50),
  ticket_quantity INT NOT NULL,
  payment_status VARCHAR(50) DEFAULT 'Pending',
  registered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (event_id) REFERENCES events(event_id)
);

Select * from events;

CREATE TABLE registrations (
  registration_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(50),
  event_id INT NOT NULL,
  ticket_type VARCHAR(50),
  ticket_quantity INT DEFAULT 1,
  payment_status VARCHAR(50) DEFAULT 'Pending',
  total_amount DECIMAL(10,2),
  registered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (event_id) REFERENCES events(event_id)
);
