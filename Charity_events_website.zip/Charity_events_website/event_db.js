const mysql = require('mysql2');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',       // default for phpMyAdmin/XAMPP
  password: '',       // usually empty
  database: 'charityevents_db'
});

const db = pool.promise();

db.getConnection()
  .then(conn => {
    console.log(" Connected to charityevents_db");
    conn.release();
  })
  .catch(err => {
    console.error(" Database connection failed:", err.message);
  });

module.exports = db;
