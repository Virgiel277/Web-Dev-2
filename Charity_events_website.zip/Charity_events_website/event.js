// helper: get query string ?id=xxx
function getEventId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

async function loadEventDetails() {
  const eventId = getEventId();
  if (!eventId) {
    document.getElementById("event-details").innerHTML = "<p> No event selected.</p>";
    return;
  }

  try {
    const res = await fetch(`http://localhost:3000/api/events/${eventId}`);
    if (!res.ok) throw new Error("Event not found");

    const event = await res.json();

    const container = document.getElementById("event-details");
    container.innerHTML = `
      <h3>${event.name}</h3>
      <p><strong>Organisation:</strong> ${event.organisation}</p>
      <p><strong>Category:</strong> ${event.category}</p>
      <p><strong>Description:</strong> ${event.description}</p>
      <p><strong>Location:</strong> ${event.location}</p>
      <p><strong>Date:</strong> ${new Date(event.event_date).toLocaleString()}</p>
      <p><strong>Tickets:</strong> ${event.ticket_type === 'free' ? 'Free' : '$' + event.ticket_price}</p>
      <p><strong>Goal Amount:</strong> $${event.goal_amount.toLocaleString()}</p>
      <p><strong>Progress:</strong> $${event.progress_amount.toLocaleString()}</p>
      <button onclick="registerEvent()">Register</button>
    `;
  } catch (err) {
    console.error(err);
    document.getElementById("event-details").innerHTML = "<p> Failed to load event details.</p>";
  }
}

function registerEvent() {
  alert("This feature is currently under construction.");
}

document.addEventListener("DOMContentLoaded", loadEventDetails);
